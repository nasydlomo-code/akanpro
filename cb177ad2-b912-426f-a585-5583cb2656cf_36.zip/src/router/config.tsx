
import type { RouteObject } from "react-router-dom";
import NotFound from "../pages/NotFound";
import Home from "../pages/home/page";
import Register from "../pages/auth/register/page";
import Login from "../pages/auth/login/page";
import Dashboard from "../pages/dashboard/page";
import Plans from "../pages/plans/page";
import Invest from "../pages/invest/page";
import Deposit from "../pages/deposit/page";
import Withdraw from "../pages/withdraw/page";
import WithdrawEarnings from "../pages/withdraw-earnings/page";
import Transfer from "../pages/transfer/page";
import Admin from "../pages/admin/page";

const routes: RouteObject[] = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/register",
    element: <Register />,
  },
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/dashboard",
    element: <Dashboard />,
  },
  {
    path: "/plans",
    element: <Plans />,
  },
  {
    path: "/invest",
    element: <Invest />,
  },
  {
    path: "/deposit",
    element: <Deposit />,
  },
  {
    path: "/withdraw",
    element: <Withdraw />,
  },
  {
    path: "/withdraw-earnings",
    element: <WithdrawEarnings />,
  },
  {
    path: "/transfer",
    element: <Transfer />,
  },
  {
    path: "/admin",
    element: <Admin />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
];

export default routes;
