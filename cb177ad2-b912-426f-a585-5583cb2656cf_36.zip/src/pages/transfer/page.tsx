
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import Button from '../../components/base/Button';
import Card from '../../components/base/Card';

export default function Transfer() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    recipientEmail: '',
    amount: '',
    note: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [recipientFound, setRecipientFound] = useState<boolean | null>(null);
  const [recipientName, setRecipientName] = useState('');

  const availableBalance = 2450.75;
  const minimumTransfer = 10;
  const transferFee = 2;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Reset recipient verification when email changes
    if (name === 'recipientEmail') {
      setRecipientFound(null);
      setRecipientName('');
    }
  };

  const verifyRecipient = async () => {
    if (!formData.recipientEmail) return;
    
    setIsLoading(true);
    
    // Simulate email verification
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Mock verification result
    const mockUsers = [
      { email: 'alice@example.com', name: 'Alice Johnson' },
      { email: 'bob@example.com', name: 'Bob Smith' },
      { email: 'carol@example.com', name: 'Carol Davis' }
    ];
    
    const foundUser = mockUsers.find(user => user.email.toLowerCase() === formData.recipientEmail.toLowerCase());
    
    if (foundUser) {
      setRecipientFound(true);
      setRecipientName(foundUser.name);
    } else {
      setRecipientFound(false);
      setRecipientName('');
    }
    
    setIsLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate transfer processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsLoading(false);
    setShowConfirmation(true);
  };

  const netAmount = formData.amount ? (parseFloat(formData.amount) + transferFee).toFixed(2) : '0.00';

  if (showConfirmation) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-md mx-auto">
            <Card className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-check-line text-3xl text-green-600"></i>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Transfer Successful</h2>
              <p className="text-gray-600 mb-6">
                Successfully transferred ${formData.amount} to {recipientName} ({formData.recipientEmail}).
                The recipient will be notified via email.
              </p>
              <div className="space-y-3">
                <Button className="w-full" onClick={() => navigate('/dashboard')}>
                  View Dashboard
                </Button>
                <Button variant="outline" className="w-full" onClick={() => navigate('/')}>
                  Back to Home
                </Button>
              </div>
            </Card>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Transfer Funds</h2>
            <p className="mt-2 text-gray-600">Send money to other registered users</p>
          </div>

          <Card className="p-8">
            <div className="mb-6 bg-gray-50 rounded-lg p-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Available Balance:</span>
                <span className="font-semibold text-gray-900">${availableBalance.toFixed(2)}</span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="recipientEmail" className="block text-sm font-medium text-gray-700 mb-2">
                  Recipient Email Address *
                </label>
                <div className="flex gap-2">
                  <input
                    type="email"
                    id="recipientEmail"
                    name="recipientEmail"
                    value={formData.recipientEmail}
                    onChange={handleInputChange}
                    required
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    placeholder="recipient@example.com"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={verifyRecipient}
                    disabled={!formData.recipientEmail || isLoading}
                    className="whitespace-nowrap"
                  >
                    {isLoading ? (
                      <i className="ri-loader-2-line animate-spin"></i>
                    ) : (
                      'Verify'
                    )}
                  </Button>
                </div>
                
                {recipientFound === true && (
                  <div className="mt-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center">
                      <i className="ri-check-circle-line text-green-600 mr-2"></i>
                      <span className="text-sm text-green-800">
                        Recipient found: <strong>{recipientName}</strong>
                      </span>
                    </div>
                  </div>
                )}
                
                {recipientFound === false && (
                  <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                    <div className="flex items-center">
                      <i className="ri-close-circle-line text-red-600 mr-2"></i>
                      <span className="text-sm text-red-800">
                        No user found with this email address
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-2">
                  Transfer Amount ($) *
                </label>
                <input
                  type="number"
                  id="amount"
                  name="amount"
                  value={formData.amount}
                  onChange={handleInputChange}
                  min={minimumTransfer}
                  max={availableBalance - transferFee}
                  step="0.01"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  placeholder="100.00"
                />
                <p className="mt-1 text-xs text-gray-500">
                  Minimum transfer: ${minimumTransfer}
                </p>
              </div>

              <div>
                <label htmlFor="note" className="block text-sm font-medium text-gray-700 mb-2">
                  Note (Optional)
                </label>
                <textarea
                  id="note"
                  name="note"
                  value={formData.note}
                  onChange={handleInputChange}
                  rows={3}
                  maxLength={200}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm resize-none"
                  placeholder="Add a message for the recipient..."
                />
                <p className="mt-1 text-xs text-gray-500">
                  {formData.note.length}/200 characters
                </p>
              </div>

              {formData.amount && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="text-sm font-medium text-blue-900 mb-2">Transfer Summary</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-blue-800">Transfer Amount:</span>
                      <span className="text-blue-900">${formData.amount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-800">Transfer Fee:</span>
                      <span className="text-blue-900">${transferFee.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between border-t pt-1">
                      <span className="text-blue-900 font-medium">Total Deducted:</span>
                      <span className="text-blue-900 font-medium">${netAmount}</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-start">
                  <i className="ri-alert-line text-yellow-600 mr-2 mt-0.5"></i>
                  <div>
                    <h4 className="text-sm font-medium text-yellow-900 mb-1">Important Notice</h4>
                    <ul className="text-xs text-yellow-800 space-y-1">
                      <li>• Transfers are instant and cannot be reversed</li>
                      <li>• Recipient must be a registered user</li>
                      <li>• Transfer fee: ${transferFee} per transaction</li>
                      <li>• Both parties will receive email notifications</li>
                    </ul>
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={
                  isLoading || 
                  !formData.amount || 
                  !formData.recipientEmail || 
                  recipientFound !== true ||
                  parseFloat(formData.amount) < minimumTransfer ||
                  parseFloat(netAmount) > availableBalance
                }
              >
                {isLoading ? (
                  <>
                    <i className="ri-loader-2-line animate-spin mr-2"></i>
                    Processing...
                  </>
                ) : (
                  <>
                    <i className="ri-send-plane-line mr-2"></i>
                    Send Transfer
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-sm text-blue-600 hover:text-blue-500 cursor-pointer"
              >
                Back to Dashboard
              </button>
            </div>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}