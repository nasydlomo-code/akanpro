import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import Button from '../../components/base/Button';
import Card from '../../components/base/Card';

export default function Withdraw() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    amount: '',
    walletAddress: '',
    paymentMethod: 'usdt'
  });
  const [isLoading, setIsLoading] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);

  const availableBalance = 2450.75;
  const minimumWithdraw = 50;
  const withdrawalFee = 5;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate withdrawal processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsLoading(false);
    setShowConfirmation(true);
  };

  const netAmount = formData.amount ? (parseFloat(formData.amount) - withdrawalFee).toFixed(2) : '0.00';

  if (showConfirmation) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-md mx-auto">
            <Card className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-check-line text-3xl text-green-600"></i>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Withdrawal Requested</h2>
              <p className="text-gray-600 mb-6">
                Your withdrawal of ${netAmount} USDT has been submitted. 
                It will be processed within 24 hours.
              </p>
              <div className="space-y-3">
                <Button className="w-full" onClick={() => navigate('/dashboard')}>
                  View Dashboard
                </Button>
                <Button variant="outline" className="w-full" onClick={() => navigate('/')}>
                  Back to Home
                </Button>
              </div>
            </Card>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Withdraw Funds</h2>
            <p className="mt-2 text-gray-600">Withdraw USDT from your account</p>
          </div>

          <Card className="p-8">
            <div className="mb-6 bg-gray-50 rounded-lg p-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Available Balance:</span>
                <span className="font-semibold text-gray-900">${availableBalance.toFixed(2)} USDT</span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-2">
                  Withdrawal Amount (USDT) *
                </label>
                <input
                  type="number"
                  id="amount"
                  name="amount"
                  value={formData.amount}
                  onChange={handleInputChange}
                  min={minimumWithdraw}
                  max={availableBalance}
                  step="0.01"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  placeholder="100.00"
                />
                <p className="mt-1 text-xs text-gray-500">
                  Minimum withdrawal: ${minimumWithdraw} USDT
                </p>
              </div>

              <div>
                <label htmlFor="paymentMethod" className="block text-sm font-medium text-gray-700 mb-2">
                  Payment Method *
                </label>
                <div className="relative">
                  <select
                    id="paymentMethod"
                    name="paymentMethod"
                    value={formData.paymentMethod}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 pr-8 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm appearance-none"
                  >
                    <option value="usdt">USDT (TRC-20)</option>
                    <option value="usdt-erc20">USDT (ERC-20)</option>
                    <option value="btc">Bitcoin (BTC)</option>
                  </select>
                  <i className="ri-arrow-down-s-line absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                </div>
              </div>

              <div>
                <label htmlFor="walletAddress" className="block text-sm font-medium text-gray-700 mb-2">
                  Wallet Address *
                </label>
                <input
                  type="text"
                  id="walletAddress"
                  name="walletAddress"
                  value={formData.walletAddress}
                  onChange={handleInputChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  placeholder="Enter your wallet address"
                />
                <p className="mt-1 text-xs text-gray-500">
                  Double-check your wallet address. Incorrect addresses may result in loss of funds.
                </p>
              </div>

              {formData.amount && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <h4 className="text-sm font-medium text-yellow-900 mb-2">Withdrawal Summary</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-yellow-800">Withdrawal Amount:</span>
                      <span className="text-yellow-900">${formData.amount} USDT</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-yellow-800">Network Fee:</span>
                      <span className="text-yellow-900">${withdrawalFee} USDT</span>
                    </div>
                    <div className="flex justify-between border-t pt-1">
                      <span className="text-yellow-900 font-medium">You will receive:</span>
                      <span className="text-yellow-900 font-medium">${netAmount} USDT</span>
                    </div>
                  </div>
                </div>
              )}

              <Button
                type="submit"
                className="w-full"
                disabled={isLoading || !formData.amount || !formData.walletAddress || parseFloat(formData.amount) < minimumWithdraw}
              >
                {isLoading ? (
                  <>
                    <i className="ri-loader-2-line animate-spin mr-2"></i>
                    Processing...
                  </>
                ) : (
                  <>
                    <i className="ri-money-dollar-box-line mr-2"></i>
                    Request Withdrawal
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-sm text-blue-600 hover:text-blue-500 cursor-pointer"
              >
                Back to Dashboard
              </button>
            </div>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}