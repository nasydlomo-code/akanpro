
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import Button from '../../components/base/Button';
import Card from '../../components/base/Card';

export default function Deposit() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    amount: '',
    paymentMethod: 'usdt-bep20',
    walletAddress: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);

  const depositAddress = '0x8AB3bF8d0dB2f70813e5B26452B2Cfe0e4835057';

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate deposit processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsLoading(false);
    setShowConfirmation(true);
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(depositAddress);
      // You could add a toast notification here
    } catch (err) {
      console.error('Failed to copy address');
    }
  };

  if (showConfirmation) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-md mx-auto">
            <Card className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-check-line text-3xl text-green-600"></i>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Deposit Initiated</h2>
              <p className="text-gray-600 mb-6">
                Your deposit of ${formData.amount} USDT has been initiated. 
                It will be processed within 15 minutes after network confirmation.
              </p>
              <div className="space-y-3">
                <Button className="w-full" onClick={() => navigate('/dashboard')}>
                  View Dashboard
                </Button>
                <Button variant="outline" className="w-full" onClick={() => navigate('/')}>
                  Back to Home
                </Button>
              </div>
            </Card>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Deposit Funds</h2>
            <p className="mt-2 text-gray-600">Add USDT to your investment account</p>
          </div>

          <Card className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-2">
                  Deposit Amount (USDT) *
                </label>
                <input
                  type="number"
                  id="amount"
                  name="amount"
                  value={formData.amount}
                  onChange={handleInputChange}
                  min="10"
                  step="0.01"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  placeholder="100.00"
                />
                <p className="mt-1 text-xs text-gray-500">Minimum deposit: $10 USDT</p>
              </div>

              <div>
                <label htmlFor="paymentMethod" className="block text-sm font-medium text-gray-700 mb-2">
                  Payment Method *
                </label>
                <div className="relative">
                  <select
                    id="paymentMethod"
                    name="paymentMethod"
                    value={formData.paymentMethod}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 pr-8 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm appearance-none"
                  >
                    <option value="usdt-bep20">USDT (BEP-20)</option>
                  </select>
                  <i className="ri-arrow-down-s-line absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start">
                  <i className="ri-information-line text-blue-600 mr-2 mt-0.5"></i>
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-blue-900 mb-2">USDT BEP-20 Deposit Address</h4>
                    <div className="bg-white rounded p-3 mb-3">
                      <p className="text-xs text-gray-800 break-all font-mono">
                        {depositAddress}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        type="button"
                        variant="outline" 
                        className="text-xs px-3 py-1 h-auto"
                        onClick={copyToClipboard}
                      >
                        <i className="ri-file-copy-line mr-1"></i>
                        Copy Address
                      </Button>
                    </div>
                    <p className="text-xs text-blue-700 mt-3">
                      Send only USDT BEP-20 to this address. Other tokens will be lost permanently. 
                      Deposits will be credited after 1 network confirmation.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-start">
                  <i className="ri-alert-line text-yellow-600 mr-2 mt-0.5"></i>
                  <div>
                    <h4 className="text-sm font-medium text-yellow-900 mb-1">Important Notice</h4>
                    <ul className="text-xs text-yellow-800 space-y-1">
                      <li>• Only send USDT on BEP-20 (Binance Smart Chain) network</li>
                      <li>• Minimum deposit amount is $10 USDT</li>
                      <li>• Deposits typically confirm within 3-5 minutes</li>
                      <li>• Contact support if deposit doesn't appear within 30 minutes</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div>
                <label htmlFor="walletAddress" className="block text-sm font-medium text-gray-700 mb-2">
                  Your Sending Wallet Address (Optional)
                </label>
                <input
                  type="text"
                  id="walletAddress"
                  name="walletAddress"
                  value={formData.walletAddress}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  placeholder="Enter your wallet address for faster processing"
                />
                <p className="mt-1 text-xs text-gray-500">
                  Providing your sending address helps us process your deposit faster
                </p>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={isLoading || !formData.amount}
              >
                {isLoading ? (
                  <>
                    <i className="ri-loader-2-line animate-spin mr-2"></i>
                    Processing...
                  </>
                ) : (
                  <>
                    <i className="ri-bank-card-line mr-2"></i>
                    Confirm Deposit
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-sm text-blue-600 hover:text-blue-500 cursor-pointer"
              >
                Back to Dashboard
              </button>
            </div>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
