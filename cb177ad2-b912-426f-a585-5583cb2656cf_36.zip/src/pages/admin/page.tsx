
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import Card from '../../components/base/Card';
import Button from '../../components/base/Button';
import { supabase } from '../../lib/supabase';

interface User {
  id: string;
  user_id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  balance: number;
  total_invested: number;
  total_returns: number;
  active_investments: number;
  referral_code: string;
  referral_earnings: number;
  total_team_members: number;
  direct_referrals: number;
  status: 'active' | 'suspended' | 'pending';
  created_at: string;
  updated_at: string;
}

interface Investment {
  id: string;
  user_id: string;
  plan_id: string;
  plan_name: string;
  amount: number;
  expected_returns: number;
  current_returns: number;
  status: 'active' | 'completed' | 'cancelled';
  start_date: string;
  end_date: string;
  created_at: string;
}

interface Transaction {
  id: string;
  user_id: string;
  type: 'deposit' | 'withdrawal' | 'investment' | 'returns' | 'transfer' | 'referral_bonus';
  amount: number;
  status: 'pending' | 'completed' | 'failed' | 'cancelled';
  description?: string;
  created_at: string;
}

export default function Admin() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('users');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showBulkMessageModal, setShowBulkMessageModal] = useState(false);
  const [showInvestmentModal, setShowInvestmentModal] = useState(false);
  const [editingInvestment, setEditingInvestment] = useState<Investment | null>(null);
  const [showReportsModal, setShowReportsModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [users, setUsers] = useState<User[]>([]);
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [bulkMessage, setBulkMessage] = useState({ subject: '', message: '' });
  const [automationSettings, setAutomationSettings] = useState({
    autoProcessReturns: true,
    dailyReturnTime: '09:00',
    autoCompleteInvestments: true,
    emailNotifications: true
  });

  useEffect(() => {
    checkAdminAccess();
    loadData();
  }, []);

  const checkAdminAccess = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user || user.email !== 'admin@investpro.com') {
      navigate('/login');
      return;
    }
  };

  const loadData = async () => {
    setIsLoading(true);
    try {
      // Load users
      const { data: usersData, error: usersError } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (usersError) throw usersError;
      setUsers(usersData || []);

      // Load investments
      const { data: investmentsData, error: investmentsError } = await supabase
        .from('investments')
        .select('*')
        .order('created_at', { ascending: false });

      if (investmentsError) throw investmentsError;
      setInvestments(investmentsData || []);

      // Load transactions
      const { data: transactionsData, error: transactionsError } = await supabase
        .from('transactions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (transactionsError) throw transactionsError;
      setTransactions(transactionsData || []);

    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredUsers = users.filter(user =>
    `${user.first_name} ${user.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.referral_code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSelectUser = (userId: string) => {
    setSelectedUsers(prev =>
      prev.includes(userId)
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  const handleSelectAll = () => {
    if (selectedUsers.length === filteredUsers.length) {
      setSelectedUsers([]);
    } else {
      setSelectedUsers(filteredUsers.map(user => user.id));
    }
  };

  const handleEditUser = (user: User) => {
    setEditingUser(user);
    setShowUserModal(true);
  };

  const handleUpdateUser = async () => {
    if (!editingUser) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          first_name: editingUser.first_name,
          last_name: editingUser.last_name,
          email: editingUser.email,
          phone: editingUser.phone,
          balance: editingUser.balance,
          status: editingUser.status,
          updated_at: new Date().toISOString()
        })
        .eq('id', editingUser.id);

      if (error) throw error;

      setUsers(prev =>
        prev.map(user =>
          user.id === editingUser.id ? editingUser : user
        )
      );
      setShowUserModal(false);
      setEditingUser(null);
    } catch (error) {
      console.error('Error updating user:', error);
    }
  };

  const handleDeleteUsers = async () => {
    try {
      const { error } = await supabase
        .from('profiles')
        .delete()
        .in('id', selectedUsers);

      if (error) throw error;

      setUsers(prev => prev.filter(user => !selectedUsers.includes(user.id)));
      setSelectedUsers([]);
      setShowDeleteConfirm(false);
    } catch (error) {
      console.error('Error deleting users:', error);
    }
  };

  const handleStatusChange = async (userId: string, newStatus: 'active' | 'suspended' | 'pending') => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ 
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', userId);

      if (error) throw error;

      setUsers(prev =>
        prev.map(user =>
          user.id === userId ? { ...user, status: newStatus } : user
        )
      );
    } catch (error) {
      console.error('Error updating user status:', error);
    }
  };

  const handleTransactionAction = async (transactionId: string, action: 'approve' | 'reject') => {
    try {
      const newStatus = action === 'approve' ? 'completed' : 'failed';
      const { error } = await supabase
        .from('transactions')
        .update({ 
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', transactionId);

      if (error) throw error;

      setTransactions(prev =>
        prev.map(transaction =>
          transaction.id === transactionId 
            ? { ...transaction, status: newStatus as any }
            : transaction
        )
      );
    } catch (error) {
      console.error('Error updating transaction:', error);
    }
  };

  const processAutomaticReturns = async () => {
    try {
      setIsLoading(true);
      
      // Get all active investments
      const activeInvestments = investments.filter(inv => inv.status === 'active');
      
      for (const investment of activeInvestments) {
        const startDate = new Date(investment.start_date);
        const endDate = new Date(investment.end_date);
        const today = new Date();
        
        // Calculate daily return (3.8% daily)
        const dailyReturn = investment.amount * 0.038;
        
        // Check if investment period is complete
        if (today >= endDate) {
          // Complete the investment
          await supabase
            .from('investments')
            .update({ 
              status: 'completed',
              current_returns: investment.expected_returns,
              updated_at: new Date().toISOString()
            })
            .eq('id', investment.id);

          // Add final return to user balance
          const user = users.find(u => u.user_id === investment.user_id);
          if (user) {
            await supabase
              .from('profiles')
              .update({ 
                balance: user.balance + investment.expected_returns,
                total_returns: user.total_returns + investment.expected_returns,
                active_investments: user.active_investments - 1,
                updated_at: new Date().toISOString()
              })
              .eq('user_id', investment.user_id);

            // Create return transaction
            await supabase
              .from('transactions')
              .insert({
                user_id: investment.user_id,
                type: 'returns',
                amount: investment.expected_returns,
                status: 'completed',
                description: `Investment completion returns for ${investment.plan_name}`
              });
          }
        } else {
          // Add daily return
          const user = users.find(u => u.user_id === investment.user_id);
          if (user) {
            await supabase
              .from('profiles')
              .update({ 
                balance: user.balance + dailyReturn,
                total_returns: user.total_returns + dailyReturn,
                updated_at: new Date().toISOString()
              })
              .eq('user_id', investment.user_id);

            // Create daily return transaction
            await supabase
              .from('transactions')
              .insert({
                user_id: investment.user_id,
                type: 'returns',
                amount: dailyReturn,
                status: 'completed',
                description: `Daily returns for ${investment.plan_name}`
              });
          }

          // Update investment current returns
          await supabase
            .from('investments')
            .update({ 
              current_returns: investment.current_returns + dailyReturn,
              updated_at: new Date().toISOString()
            })
            .eq('id', investment.id);
        }
      }

      // Reload data
      await loadData();
      
    } catch (error) {
      console.error('Error processing automatic returns:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Bulk actions
  const handleBulkAction = async (action: 'activate' | 'suspend' | 'send_message') => {
    if (selectedUsers.length === 0) return;

    try {
      if (action === 'send_message') {
        setShowBulkMessageModal(true);
        return;
      }

      const newStatus = action === 'activate' ? 'active' : 'suspended';
      
      for (const userId of selectedUsers) {
        await supabase
          .from('profiles')
          .update({ 
            status: newStatus,
            updated_at: new Date().toISOString()
          })
          .eq('id', userId);
      }

      setUsers(prev =>
        prev.map(user =>
          selectedUsers.includes(user.id) ? { ...user, status: newStatus } : user
        )
      );
      
      setSelectedUsers([]);
    } catch (error) {
      console.error('Error performing bulk action:', error);
    }
  };

  const handleSendBulkMessage = async () => {
    try {
      // In a real app, you'd send emails or notifications
      // For now, we'll create transaction records as notifications
      for (const userId of selectedUsers) {
        const user = users.find(u => u.id === userId);
        if (user) {
          await supabase
            .from('transactions')
            .insert({
              user_id: user.user_id,
              type: 'deposit', // Using as notification type
              amount: 0,
              status: 'completed',
              description: `Admin Message: ${bulkMessage.subject} - ${bulkMessage.message}`
            });
        }
      }

      setBulkMessage({ subject: '', message: '' });
      setShowBulkMessageModal(false);
      setSelectedUsers([]);
    } catch (error) {
      console.error('Error sending bulk message:', error);
    }
  };

  const handleEditInvestment = (investment: Investment) => {
    setEditingInvestment(investment);
    setShowInvestmentModal(true);
  };

  const handleUpdateInvestment = async () => {
    if (!editingInvestment) return;

    try {
      const { error } = await supabase
        .from('investments')
        .update({
          status: editingInvestment.status,
          current_returns: editingInvestment.current_returns,
          updated_at: new Date().toISOString()
        })
        .eq('id', editingInvestment.id);

      if (error) throw error;

      setInvestments(prev =>
        prev.map(investment =>
          investment.id === editingInvestment.id ? editingInvestment : investment
        )
      );
      setShowInvestmentModal(false);
      setEditingInvestment(null);
    } catch (error) {
      console.error('Error updating investment:', error);
    }
  };

  const generateReport = async (type: 'users' | 'investments' | 'transactions') => {
    try {
      let data: any[] = [];
      let filename = '';
      
      switch (type) {
        case 'users':
          data = users.map(user => ({
            Name: `${user.first_name} ${user.last_name}`,
            Email: user.email,
            Balance: user.balance,
            'Total Invested': user.total_invested,
            'Total Returns': user.total_returns,
            'Active Investments': user.active_investments,
            Referrals: user.direct_referrals,
            Status: user.status,
            'Join Date': new Date(user.created_at).toLocaleDateString()
          }));
          filename = 'users_report.csv';
          break;
        case 'investments':
          data = investments.map(investment => {
            const user = users.find(u => u.user_id === investment.user_id);
            return {
              User: user ? `${user.first_name} ${user.last_name}` : 'Unknown',
              Plan: investment.plan_name,
              Amount: investment.amount,
              'Expected Returns': investment.expected_returns,
              'Current Returns': investment.current_returns,
              Status: investment.status,
              'Start Date': new Date(investment.start_date).toLocaleDateString(),
              'End Date': new Date(investment.end_date).toLocaleDateString()
            };
          });
          filename = 'investments_report.csv';
          break;
        case 'transactions':
          data = transactions.map(transaction => {
            const user = users.find(u => u.user_id === transaction.user_id);
            return {
              User: user ? `${user.first_name} ${user.last_name}` : 'Unknown',
              Type: transaction.type,
              Amount: transaction.amount,
              Status: transaction.status,
              Description: transaction.description || '',
              Date: new Date(transaction.created_at).toLocaleDateString()
            };
          });
          filename = 'transactions_report.csv';
          break;
      }

      // Convert to CSV
      const headers = Object.keys(data[0] || {});
      const csvContent = [
        headers.join(','),
        ...data.map(row => headers.map(header => `"${row[header]}"`).join(','))
      ].join('\n');

      // Download file
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.click();
      window.URL.revokeObjectURL(url);
      
    } catch (error) {
      console.error('Error generating report:', error);
    }
  };

  const TabButton = ({ id, label, active, onClick }: { id: string; label: string; active: boolean; onClick: () => void }) => (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap cursor-pointer ${
        active 
          ? 'bg-blue-600 text-white' 
          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
      }`}
    >
      {label}
    </button>
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': case 'completed': return 'bg-green-100 text-green-800';
      case 'suspended': case 'failed': case 'cancelled': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <i className="ri-loader-2-line text-4xl text-blue-600 animate-spin mb-4"></i>
          <p className="text-gray-600">Loading admin panel...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Admin Panel</h1>
            <p className="mt-2 text-gray-600">Manage users, investments, and platform automation</p>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <i className="ri-user-line text-2xl text-blue-600"></i>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Users</p>
                  <p className="text-2xl font-bold text-gray-900">{users.length}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <i className="ri-user-follow-line text-2xl text-green-600"></i>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Users</p>
                  <p className="text-2xl font-bold text-gray-900">{users.filter(u => u.status === 'active').length}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <i className="ri-money-dollar-circle-line text-2xl text-purple-600"></i>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Invested</p>
                  <p className="text-2xl font-bold text-gray-900">${users.reduce((sum, u) => sum + u.total_invested, 0).toLocaleString()}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <i className="ri-bar-chart-line text-2xl text-orange-600"></i>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Investments</p>
                  <p className="text-2xl font-bold text-gray-900">{investments.filter(i => i.status === 'active').length}</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Tab Navigation */}
          <div className="flex space-x-2 mb-6 overflow-x-auto pb-2">
            <TabButton id="users" label="User Management" active={activeTab === 'users'} onClick={() => setActiveTab('users')} />
            <TabButton id="investments" label="Investments" active={activeTab === 'investments'} onClick={() => setActiveTab('investments')} />
            <TabButton id="transactions" label="Transactions" active={activeTab === 'transactions'} onClick={() => setActiveTab('transactions')} />
            <TabButton id="automation" label="Automation" active={activeTab === 'automation'} onClick={() => setActiveTab('automation')} />
            <TabButton id="analytics" label="Analytics" active={activeTab === 'analytics'} onClick={() => setActiveTab('analytics')} />
          </div>

          {/* User Management Tab */}
          {activeTab === 'users' && (
            <Card className="p-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                <h3 className="text-lg font-semibold text-gray-900">User Management</h3>
                <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Search users..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm w-full sm:w-64"
                    />
                    <i className="ri-search-line absolute left-3 top-2.5 text-gray-400"></i>
                  </div>
                  <Button size="sm" onClick={() => generateReport('users')}>
                    <i className="ri-download-line mr-2"></i>
                    Export CSV
                  </Button>
                </div>
              </div>

              {selectedUsers.length > 0 && (
                <div className="mb-4 p-4 bg-blue-50 rounded-lg flex flex-wrap gap-2 items-center justify-between">
                  <span className="text-sm font-medium text-blue-900">
                    {selectedUsers.length} user{selectedUsers.length > 1 ? 's' : ''} selected
                  </span>
                  <div className="flex gap-2">
                    <Button size="sm" variant="success" onClick={() => handleBulkAction('activate')}>
                      <i className="ri-check-line mr-1"></i>
                      Activate
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleBulkAction('suspend')}>
                      <i className="ri-pause-line mr-1"></i>
                      Suspend
                    </Button>
                    <Button size="sm" onClick={() => handleBulkAction('send_message')}>
                      <i className="ri-mail-line mr-1"></i>
                      Message
                    </Button>
                    <Button size="sm" variant="danger" onClick={() => setShowDeleteConfirm(true)}>
                      <i className="ri-delete-bin-line mr-1"></i>
                      Delete
                    </Button>
                  </div>
                </div>
              )}

              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">
                        <input
                          type="checkbox"
                          checked={selectedUsers.length === filteredUsers.length && filteredUsers.length > 0}
                          onChange={handleSelectAll}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded cursor-pointer"
                        />
                      </th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">User</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Status</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Balance</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Total Invested</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Referrals</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Join Date</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map((user) => (
                      <tr key={user.id} className="border-b hover:bg-gray-50">
                        <td className="py-4 px-4">
                          <input
                            type="checkbox"
                            checked={selectedUsers.includes(user.id)}
                            onChange={() => handleSelectUser(user.id)}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded cursor-pointer"
                          />
                        </td>
                        <td className="py-4 px-4">
                          <div>
                            <div className="font-medium text-gray-900">{user.first_name} {user.last_name}</div>
                            <div className="text-sm text-gray-500">{user.email}</div>
                            <div className="text-xs text-gray-400">ID: {user.referral_code}</div>
                          </div>
                        </td>
                        <td className="py-4 px-4">
                          <div className="relative">
                            <select
                              value={user.status}
                              onChange={(e) => handleStatusChange(user.id, e.target.value as any)}
                              className={`text-xs font-medium px-2 py-1 rounded-full border-0 focus:ring-2 focus:ring-blue-500 cursor-pointer pr-8 ${getStatusColor(user.status)}`}
                            >
                              <option value="active">Active</option>
                              <option value="suspended">Suspended</option>
                              <option value="pending">Pending</option>
                            </select>
                          </div>
                        </td>
                        <td className="py-4 px-4 font-semibold text-green-600">${user.balance.toLocaleString()}</td>
                        <td className="py-4 px-4">${user.total_invested.toLocaleString()}</td>
                        <td className="py-4 px-4">
                          <div className="flex items-center">
                            <span className="mr-2">{user.direct_referrals}</span>
                            <span className="text-xs text-gray-500">(${user.referral_earnings.toFixed(2)})</span>
                          </div>
                        </td>
                        <td className="py-4 px-4 text-sm text-gray-500">{new Date(user.created_at).toLocaleDateString()}</td>
                        <td className="py-4 px-4">
                          <div className="flex space-x-2">
                            <button
                              onClick={() => handleEditUser(user)}
                              className="text-blue-600 hover:text-blue-800 cursor-pointer"
                              title="Edit User"
                            >
                              <i className="ri-edit-line"></i>
                            </button>
                            <button
                              onClick={() => {
                                setSelectedUsers([user.id]);
                                setShowDeleteConfirm(true);
                              }}
                              className="text-red-600 hover:text-red-800 cursor-pointer"
                              title="Delete User"
                            >
                              <i className="ri-delete-bin-line"></i>
                            </button>
                            <button
                              onClick={() => navigate(`/admin/user/${user.user_id}`)}
                              className="text-gray-600 hover:text-gray-800 cursor-pointer"
                              title="View Details"
                            >
                              <i className="ri-eye-line"></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          )}

          {/* Investments Tab */}
          {activeTab === 'investments' && (
            <Card className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Investment Management</h3>
                <Button size="sm" onClick={() => generateReport('investments')}>
                  <i className="ri-download-line mr-2"></i>
                  Export CSV
                </Button>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-medium text-gray-600">User</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Plan</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Amount</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Progress</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Current Returns</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Status</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Duration</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {investments.map((investment) => {
                      const user = users.find(u => u.user_id === investment.user_id);
                      const progress = (investment.current_returns / investment.expected_returns) * 100;
                      const startDate = new Date(investment.start_date);
                      const endDate = new Date(investment.end_date);
                      const today = new Date();
                      const totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
                      const daysLeft = Math.max(0, Math.ceil((endDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
                      
                      return (
                        <tr key={investment.id} className="border-b hover:bg-gray-50">
                          <td className="py-4 px-4 font-medium text-gray-900">
                            {user ? `${user.first_name} ${user.last_name}` : 'Unknown User'}
                          </td>
                          <td className="py-4 px-4">
                            <div>
                              <div className="font-medium">{investment.plan_name}</div>
                              <div className="text-xs text-gray-500">ID: {investment.plan_id}</div>
                            </div>
                          </td>
                          <td className="py-4 px-4 font-semibold">${investment.amount.toLocaleString()}</td>
                          <td className="py-4 px-4">
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-blue-600 h-2 rounded-full" 
                                style={{ width: `${Math.min(progress, 100)}%` }}
                              ></div>
                            </div>
                            <div className="text-xs text-gray-500 mt-1">{progress.toFixed(1)}%</div>
                          </td>
                          <td className="py-4 px-4 font-semibold text-green-600">${investment.current_returns.toFixed(2)}</td>
                          <td className="py-4 px-4">
                            <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(investment.status)}`}>
                              {investment.status}
                            </span>
                          </td>
                          <td className="py-4 px-4 text-sm">
                            <div>{daysLeft} days left</div>
                            <div className="text-xs text-gray-500">of {totalDays} total</div>
                          </td>
                          <td className="py-4 px-4">
                            <div className="flex space-x-2">
                              <button
                                onClick={() => handleEditInvestment(investment)}
                                className="text-blue-600 hover:text-blue-800 cursor-pointer"
                                title="Edit Investment"
                              >
                                <i className="ri-edit-line"></i>
                              </button>
                              {investment.status === 'active' && (
                                <button
                                  onClick={async () => {
                                    await supabase
                                      .from('investments')
                                      .update({ status: 'cancelled', updated_at: new Date().toISOString() })
                                      .eq('id', investment.id);
                                    loadData();
                                  }}
                                  className="text-red-600 hover:text-red-800 cursor-pointer"
                                  title="Cancel Investment"
                                >
                                  <i className="ri-close-line"></i>
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </Card>
          )}

          {/* Transactions Tab */}
          {activeTab === 'transactions' && (
            <Card className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Transaction Management</h3>
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => generateReport('transactions')}>
                    <i className="ri-download-line mr-2"></i>
                    Export CSV
                  </Button>
                  <Button size="sm" onClick={loadData}>
                    <i className="ri-refresh-line mr-2"></i>
                    Refresh
                  </Button>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-medium text-gray-600">User</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Type</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Amount</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Status</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Description</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Date</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map((transaction) => {
                      const user = users.find(u => u.user_id === transaction.user_id);
                      return (
                        <tr key={transaction.id} className="border-b hover:bg-gray-50">
                          <td className="py-4 px-4 font-medium text-gray-900">
                            {user ? `${user.first_name} ${user.last_name}` : 'Unknown User'}
                          </td>
                          <td className="py-4 px-4">
                            <span className="capitalize font-medium">{transaction.type.replace('_', ' ')}</span>
                          </td>
                          <td className={`py-4 px-4 font-semibold ${
                            ['deposit', 'returns', 'referral_bonus'].includes(transaction.type) 
                              ? 'text-green-600' 
                              : 'text-red-600'
                          }`}>
                            {['deposit', 'returns', 'referral_bonus'].includes(transaction.type) ? '+' : '-'}
                            ${Math.abs(transaction.amount).toLocaleString()}
                          </td>
                          <td className="py-4 px-4">
                            <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(transaction.status)}`}>
                              {transaction.status}
                            </span>
                          </td>
                          <td className="py-4 px-4 text-sm text-gray-600 max-w-xs truncate">
                            {transaction.description || 'No description'}
                          </td>
                          <td className="py-4 px-4 text-sm">
                            <div>{new Date(transaction.created_at).toLocaleDateString()}</div>
                            <div className="text-xs text-gray-500">{new Date(transaction.created_at).toLocaleTimeString()}</div>
                          </td>
                          <td className="py-4 px-4">
                            {transaction.status === 'pending' && (
                              <div className="flex space-x-2">
                                <Button 
                                  size="sm" 
                                  variant="success"
                                  onClick={() => handleTransactionAction(transaction.id, 'approve')}
                                >
                                  <i className="ri-check-line"></i>
                                  Approve
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="danger"
                                  onClick={() => handleTransactionAction(transaction.id, 'reject')}
                                >
                                  <i className="ri-close-line"></i>
                                  Reject
                                </Button>
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </Card>
          )}

          {/* Automation Tab */}
          {activeTab === 'automation' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Investment Automation</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                    <div>
                      <h4 className="font-medium text-blue-900">Auto Process Returns</h4>
                      <p className="text-sm text-blue-700">Automatically process daily returns for active investments</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={automationSettings.autoProcessReturns}
                        onChange={(e) => setAutomationSettings(prev => ({
                          ...prev,
                          autoProcessReturns: e.target.checked
                        }))}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                    <div>
                      <h4 className="font-medium text-green-900">Auto Complete Investments</h4>
                      <p className="text-sm text-green-700">Automatically complete investments when duration ends</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={automationSettings.autoCompleteInvestments}
                        onChange={(e) => setAutomationSettings(prev => ({
                          ...prev,
                          autoCompleteInvestments: e.target.checked
                        }))}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                    </label>
                  </div>

                  <div className="p-4 bg-purple-50 rounded-lg">
                    <h4 className="font-medium text-purple-900 mb-2">Daily Return Processing Time</h4>
                    <input
                      type="time"
                      value={automationSettings.dailyReturnTime}
                      onChange={(e) => setAutomationSettings(prev => ({
                        ...prev,
                        dailyReturnTime: e.target.value
                      }))}
                      className="w-full px-3 py-2 border border-purple-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-sm"
                    />
                  </div>

                  <Button 
                    className="w-full"
                    onClick={processAutomaticReturns}
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <i className="ri-loader-2-line animate-spin mr-2"></i>
                        Processing Returns...
                      </>
                    ) : (
                      <>
                        <i className="ri-play-circle-line mr-2"></i>
                        Process Returns Now
                      </>
                    )}
                  </Button>
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">System Status</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                      <div>
                        <h4 className="font-medium text-green-900">Database</h4>
                        <p className="text-sm text-green-700">Connected and operational</p>
                      </div>
                    </div>
                    <i className="ri-database-2-line text-2xl text-green-600"></i>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                      <div>
                        <h4 className="font-medium text-green-900">Authentication</h4>
                        <p className="text-sm text-green-700">Supabase Auth active</p>
                      </div>
                    </div>
                    <i className="ri-shield-check-line text-2xl text-green-600"></i>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                      <div>
                        <h4 className="font-medium text-blue-900">Automation Engine</h4>
                        <p className="text-sm text-blue-700">Ready for processing</p>
                      </div>
                    </div>
                    <i className="ri-robot-line text-2xl text-blue-600"></i>
                  </div>

                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h4 className="font-medium text-gray-900 mb-2">Last Automation Run</h4>
                    <p className="text-sm text-gray-600">
                      {new Date().toLocaleString()}
                    </p>
                  </div>
                </div>
              </Card>
            </div>
          )}

          {/* Analytics Tab */}
          {activeTab === 'analytics' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Platform Statistics</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600">Total Platform Value</p>
                      <p className="text-2xl font-bold text-blue-600">
                        ${users.reduce((sum, u) => sum + u.balance, 0).toLocaleString()}
                      </p>
                    </div>
                    <i className="ri-money-dollar-circle-line text-3xl text-blue-600"></i>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600">Total Returns Paid</p>
                      <p className="text-2xl font-bold text-green-600">
                        ${users.reduce((sum, u) => sum + u.total_returns, 0).toLocaleString()}
                      </p>
                    </div>
                    <i className="ri-line-chart-line text-3xl text-green-600"></i>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-purple-50 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600">Total Referrals</p>
                      <p className="text-2xl font-bold text-purple-600">
                        {users.reduce((sum, u) => sum + u.direct_referrals, 0)}
                      </p>
                    </div>
                    <i className="ri-team-line text-3xl text-purple-600"></i>
                  </div>
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">User Distribution</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Active Users</span>
                    <div className="flex items-center">
                      <div className="w-24 bg-gray-200 rounded-full h-2 mr-2">
                        <div 
                          className="bg-green-600 h-2 rounded-full" 
                          style={{ width: `${users.length > 0 ? (users.filter(u => u.status === 'active').length / users.length) * 100 : 0}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium">{users.filter(u => u.status === 'active').length}</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Suspended Users</span>
                    <div className="flex items-center">
                      <div className="w-24 bg-gray-200 rounded-full h-2 mr-2">
                        <div 
                          className="bg-red-600 h-2 rounded-full" 
                          style={{ width: `${users.length > 0 ? (users.filter(u => u.status === 'suspended').length / users.length) * 100 : 0}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium">{users.filter(u => u.status === 'suspended').length}</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Pending Users</span>
                    <div className="flex items-center">
                      <div className="w-24 bg-gray-200 rounded-full h-2 mr-2">
                        <div 
                          className="bg-yellow-600 h-2 rounded-full" 
                          style={{ width: `${users.length > 0 ? (users.filter(u => u.status === 'pending').length / users.length) * 100 : 0}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium">{users.filter(u => u.status === 'pending').length}</span>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          )}

          {/* Edit User Modal */}
          {showUserModal && editingUser && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-lg max-w-2xl w-full p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-semibold text-gray-900">Edit User: {editingUser.first_name} {editingUser.last_name}</h3>
                  <button
                    onClick={() => setShowUserModal(false)}
                    className="text-gray-400 hover:text-gray-600 cursor-pointer"
                  >
                    <i className="ri-close-line text-xl"></i>
                  </button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                    <input
                      type="text"
                      value={editingUser.first_name}
                      onChange={(e) => setEditingUser(prev => prev ? {...prev, first_name: e.target.value} : null)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                    <input
                      type="text"
                      value={editingUser.last_name}
                      onChange={(e) => setEditingUser(prev => prev ? {...prev, last_name: e.target.value} : null)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <input
                      type="email"
                      value={editingUser.email}
                      onChange={(e) => setEditingUser(prev => prev ? {...prev, email: e.target.value} : null)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                    <input
                      type="tel"
                      value={editingUser.phone || ''}
                      onChange={(e) => setEditingUser(prev => prev ? {...prev, phone: e.target.value} : null)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                    <select
                      value={editingUser.status}
                      onChange={(e) => setEditingUser(prev => prev ? {...prev, status: e.target.value as any} : null)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm cursor-pointer pr-8"
                    >
                      <option value="active">Active</option>
                      <option value="suspended">Suspended</option>
                      <option value="pending">Pending</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Balance</label>
                    <input
                      type="number"
                      value={editingUser.balance}
                      onChange={(e) => setEditingUser(prev => prev ? {...prev, balance: parseFloat(e.target.value) || 0} : null)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    />
                  </div>
                </div>
                
                <div className="flex justify-end space-x-3 mt-6">
                  <Button variant="outline" onClick={() => setShowUserModal(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleUpdateUser}>
                    Save Changes
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Delete Confirmation Modal */}
          {showDeleteConfirm && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-lg max-w-md w-full p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mr-4">
                    <i className="ri-delete-bin-line text-2xl text-red-600"></i>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Delete Users</h3>
                    <p className="text-sm text-gray-600">This action cannot be undone</p>
                  </div>
                </div>
                
                <p className="text-gray-600 mb-6">
                  Are you sure you want to delete {selectedUsers.length} user{selectedUsers.length > 1 ? 's' : ''}? 
                  This will permanently remove their accounts and all associated data.
                </p>
                
                <div className="flex justify-end space-x-3">
                  <Button variant="outline" onClick={() => setShowDeleteConfirm(false)}>
                    Cancel
                  </Button>
                  <Button variant="danger" onClick={handleDeleteUsers}>
                    Delete Users
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Bulk Message Modal */}
          {showBulkMessageModal && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-lg max-w-2xl w-full p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-semibold text-gray-900">Send Message to {selectedUsers.length} Users</h3>
                  <button
                    onClick={() => setShowBulkMessageModal(false)}
                    className="text-gray-400 hover:text-gray-600 cursor-pointer"
                  >
                    <i className="ri-close-line text-xl"></i>
                  </button>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Subject</label>
                    <input
                      type="text"
                      value={bulkMessage.subject}
                      onChange={(e) => setBulkMessage(prev => ({...prev, subject: e.target.value}))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      placeholder="Message subject..."
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                    <textarea
                      value={bulkMessage.message}
                      onChange={(e) => setBulkMessage(prev => ({...prev, message: e.target.value}))}
                      rows={4}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      placeholder="Type your message here..."
                    />
                  </div>
                </div>
                
                <div className="flex justify-end space-x-3 mt-6">
                  <Button variant="outline" onClick={() => setShowBulkMessageModal(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleSendBulkMessage} disabled={!bulkMessage.subject || !bulkMessage.message}>
                    <i className="ri-send-plane-line mr-2"></i>
                    Send Message
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Edit Investment Modal */}
          {showInvestmentModal && editingInvestment && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-lg max-w-2xl w-full p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-semibold text-gray-900">Edit Investment</h3>
                  <button
                    onClick={() => setShowInvestmentModal(false)}
                    className="text-gray-400 hover:text-gray-600 cursor-pointer"
                  >
                    <i className="ri-close-line text-xl"></i>
                  </button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                    <select
                      value={editingInvestment.status}
                      onChange={(e) => setEditingInvestment(prev => prev ? {...prev, status: e.target.value as any} : null)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm cursor-pointer pr-8"
                    >
                      <option value="active">Active</option>
                      <option value="completed">Completed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Current Returns</label>
                    <input
                      type="number"
                      step="0.01"
                      value={editingInvestment.current_returns}
                      onChange={(e) => setEditingInvestment(prev => prev ? {...prev, current_returns: parseFloat(e.target.value) || 0} : null)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-medium text-gray-900 mb-2">Investment Details</h4>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Plan:</span>
                          <span className="ml-2 font-medium">{editingInvestment.plan_name}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Amount:</span>
                          <span className="ml-2 font-medium">${editingInvestment.amount.toLocaleString()}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Expected Returns:</span>
                          <span className="ml-2 font-medium">${editingInvestment.expected_returns.toLocaleString()}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Progress:</span>
                          <span className="ml-2 font-medium">{((editingInvestment.current_returns / editingInvestment.expected_returns) * 100).toFixed(1)}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end space-x-3 mt-6">
                  <Button variant="outline" onClick={() => setShowInvestmentModal(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleUpdateInvestment}>
                    Save Changes
                  </Button>
                </div>
              </div>
            </div>
          )}

          <Footer />
        </div>
      </div>
    </div>
  );
}
