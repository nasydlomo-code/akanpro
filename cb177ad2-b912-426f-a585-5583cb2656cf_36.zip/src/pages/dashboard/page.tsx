
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import Card from '../../components/base/Card';
import Button from '../../components/base/Button';

export default function Dashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [showShareModal, setShowShareModal] = useState(false);
  
  // Get user data from localStorage or use default values for new users
  const storedUserData = localStorage.getItem('userData');
  const defaultUserData = {
    name: 'John Doe',
    email: 'john@example.com',
    balance: 0.00,
    totalInvested: 0.00,
    totalReturns: 0.00,
    activeInvestments: 0,
    referralCode: 'INV12345',
    referralEarnings: 0.00,
    totalTeamMembers: 0,
    directReferrals: 0
  };
  
  const userData = storedUserData ? JSON.parse(storedUserData) : defaultUserData;

  const investments = [
    { id: 1, plan: 'WC-R550', amount: 32, returns: 11.52, status: 'Active', daysLeft: 12 },
    { id: 2, plan: 'WC-R1150', amount: 67, returns: 24.12, status: 'Active', daysLeft: 8 },
    { id: 3, plan: 'WC-R3100', amount: 179, returns: 64.44, status: 'Active', daysLeft: 20 }
  ];

  const transactions = [
    { id: 1, type: 'Deposit', amount: 1000, date: '2024-01-15', status: 'Completed' },
    { id: 2, type: 'Investment', amount: -550, date: '2024-01-16', status: 'Active' },
    { id: 3, type: 'Returns', amount: 82.50, date: '2024-01-20', status: 'Completed' },
    { id: 4, type: 'Withdrawal', amount: -200, date: '2024-01-22', status: 'Pending' }
  ];

  const TabButton = ({ id, label, active, onClick }: { id: string; label: string; active: boolean; onClick: () => void }) => (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap cursor-pointer ${
        active 
          ? 'bg-blue-600 text-white' 
          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
      }`}
    >
      {label}
    </button>
  );

  const copyReferralCode = async () => {
    try {
      await navigator.clipboard.writeText(userData.referralCode);
    } catch (err) {
      console.error('Failed to copy referral code');
    }
  };

  const copyReferralLink = async () => {
    try {
      await navigator.clipboard.writeText(`https://investpro.com/register?ref=${userData.referralCode}`);
    } catch (err) {
      console.error('Failed to copy referral link');
    }
  };

  const shareReferralLink = () => {
    setShowShareModal(true);
  };

  const shareVia = (platform: string) => {
    const referralLink = `https://investpro.com/register?ref=${userData.referralCode}`;
    const message = `Join me on InvestPro and start earning passive income! Use my referral code: ${userData.referralCode}`;
    
    let shareUrl = '';
    
    switch (platform) {
      case 'whatsapp':
        shareUrl = `https://wa.me/?text=${encodeURIComponent(message + ' ' + referralLink)}`;
        break;
      case 'telegram':
        shareUrl = `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent(message)}`;
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(message)}&url=${encodeURIComponent(referralLink)}`;
        break;
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralLink)}`;
        break;
      case 'email':
        shareUrl = `mailto:?subject=${encodeURIComponent('Join InvestPro with my referral')}&body=${encodeURIComponent(message + '\n\n' + referralLink)}`;
        break;
    }
    
    if (shareUrl) {
      window.open(shareUrl, '_blank');
    }
    setShowShareModal(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Investment Dashboard</h1>
            <p className="mt-2 text-gray-600">Welcome back, {userData.name}</p>
          </div>

          {/* Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <i className="ri-wallet-3-line text-2xl text-blue-600"></i>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Current Balance</p>
                  <p className="text-2xl font-bold text-gray-900">${userData.balance.toFixed(2)}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <i className="ri-trending-up-line text-2xl text-green-600"></i>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Invested</p>
                  <p className="text-2xl font-bold text-gray-900">${userData.totalInvested.toFixed(2)}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <i className="ri-money-dollar-circle-line text-2xl text-purple-600"></i>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Returns</p>
                  <p className="text-2xl font-bold text-gray-900">${userData.totalReturns.toFixed(2)}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <i className="ri-bar-chart-line text-2xl text-orange-600"></i>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Plans</p>
                  <p className="text-2xl font-bold text-gray-900">{userData.activeInvestments}</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Referral Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center">
                  <i className="ri-team-line text-2xl text-teal-600"></i>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Team Members</p>
                  <p className="text-2xl font-bold text-gray-900">{userData.totalTeamMembers}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <i className="ri-user-add-line text-2xl text-indigo-600"></i>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Direct Referrals</p>
                  <p className="text-2xl font-bold text-gray-900">{userData.directReferrals}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center">
                  <i className="ri-money-dollar-box-line text-2xl text-emerald-600"></i>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Referral Earnings</p>
                  <p className="text-2xl font-bold text-gray-900">${userData.referralEarnings.toFixed(2)}</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Tab Navigation */}
          <div className="flex space-x-2 mb-6 overflow-x-auto pb-2">
            <TabButton id="overview" label="Overview" active={activeTab === 'overview'} onClick={() => setActiveTab('overview')} />
            <TabButton id="investments" label="My Investments" active={activeTab === 'investments'} onClick={() => setActiveTab('investments')} />
            <TabButton id="transactions" label="Transactions" active={activeTab === 'transactions'} onClick={() => setActiveTab('transactions')} />
            <TabButton id="affiliate" label="Affiliate" active={activeTab === 'affiliate'} onClick={() => setActiveTab('affiliate')} />
          </div>

          {/* Tab Content */}
          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
                <div className="space-y-4">
                  {transactions.slice(0, 3).map((transaction) => (
                    <div key={transaction.id} className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          transaction.type === 'Deposit' ? 'bg-green-100' :
                          transaction.type === 'Investment' ? 'bg-blue-100' :
                          transaction.type === 'Returns' ? 'bg-purple-100' : 'bg-orange-100'
                        }`}>
                          <i className={`text-sm ${
                            transaction.type === 'Deposit' ? 'ri-add-line text-green-600' :
                            transaction.type === 'Investment' ? 'ri-rocket-line text-blue-600' :
                            transaction.type === 'Returns' ? 'ri-money-dollar-line text-purple-600' : 'ri-subtract-line text-orange-600'
                          }`}></i>
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-gray-900">{transaction.type}</p>
                          <p className="text-xs text-gray-500">{transaction.date}</p>
                        </div>
                      </div>
                      <span className={`font-semibold ${transaction.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {transaction.amount > 0 ? '+' : ''}${Math.abs(transaction.amount).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
                <div className="grid grid-cols-2 gap-4">
                  <Button className="h-20 flex-col" onClick={() => navigate('/invest')}>
                    <i className="ri-add-circle-line text-2xl mb-2"></i>
                    New Investment
                  </Button>
                  <Button variant="outline" className="h-20 flex-col" onClick={() => navigate('/deposit')}>
                    <i className="ri-bank-card-line text-2xl mb-2"></i>
                    Deposit Funds
                  </Button>
                  <Button variant="outline" className="h-20 flex-col" onClick={() => navigate('/transfer')}>
                    <i className="ri-send-plane-line text-2xl mb-2"></i>
                    Transfer Funds
                  </Button>
                  <Button variant="outline" className="h-20 flex-col" onClick={() => navigate('/withdraw')}>
                    <i className="ri-money-dollar-box-line text-2xl mb-2"></i>
                    Withdraw
                  </Button>
                </div>
                <div className="grid grid-cols-1 gap-4 mt-4">
                  <Button variant="outline" className="h-16 flex-col" onClick={() => navigate('/withdraw-earnings')}>
                    <i className="ri-withdraw-line text-2xl mb-2"></i>
                    Withdraw Earnings
                  </Button>
                </div>
              </Card>
            </div>
          )}

          {activeTab === 'investments' && (
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Active Investments</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Plan</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Amount</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Returns</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Status</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Days Left</th>
                    </tr>
                  </thead>
                  <tbody>
                    {investments.map((investment) => (
                      <tr key={investment.id} className="border-b">
                        <td className="py-4 px-4 font-medium text-gray-900">{investment.plan}</td>
                        <td className="py-4 px-4">${investment.amount.toFixed(2)}</td>
                        <td className="py-4 px-4 text-green-600 font-semibold">${investment.returns.toFixed(2)}</td>
                        <td className="py-4 px-4">
                          <span className="inline-flex px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                            {investment.status}
                          </span>
                        </td>
                        <td className="py-4 px-4">{investment.daysLeft} days</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          )}

          {activeTab === 'transactions' && (
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Transaction History</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Type</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Amount</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Date</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-600">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map((transaction) => (
                      <tr key={transaction.id} className="border-b">
                        <td className="py-4 px-4 font-medium text-gray-900">{transaction.type}</td>
                        <td className={`py-4 px-4 font-semibold ${transaction.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {transaction.amount > 0 ? '+' : ''}${Math.abs(transaction.amount).toFixed(2)}
                        </td>
                        <td className="py-4 px-4">{transaction.date}</td>
                        <td className="py-4 px-4">
                          <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                            transaction.status === 'Completed' ? 'bg-green-100 text-green-800' :
                            transaction.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {transaction.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          )}

          {activeTab === 'affiliate' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Referral Program</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-2">Your Referral Code</label>
                    <div className="flex">
                      <input
                        type="text"
                        value={userData.referralCode}
                        readOnly
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-l-lg bg-gray-50 text-sm"
                      />
                      <Button className="rounded-l-none" onClick={copyReferralCode}>
                        <i className="ri-file-copy-line"></i>
                      </Button>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-2">Referral Link</label>
                    <div className="flex">
                      <input
                        type="text"
                        value={`https://investpro.com/register?ref=${userData.referralCode}`}
                        readOnly
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-l-lg bg-gray-50 text-sm"
                      />
                      <Button className="rounded-l-none" onClick={shareReferralLink}>
                        <i className="ri-share-line"></i>
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Team Statistics */}
                <div className="mt-6 pt-6 border-t">
                  <h4 className="text-sm font-medium text-gray-900 mb-3">Team Statistics</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-teal-50 rounded-lg">
                      <div className="text-2xl font-bold text-teal-600">{userData.totalTeamMembers}</div>
                      <div className="text-xs text-teal-700">Total Team</div>
                    </div>
                    <div className="text-center p-3 bg-indigo-50 rounded-lg">
                      <div className="text-2xl font-bold text-indigo-600">{userData.directReferrals}</div>
                      <div className="text-xs text-indigo-700">Direct Referrals</div>
                    </div>
                  </div>
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Earnings Summary</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600">Total Referral Earnings</p>
                      <p className="text-2xl font-bold text-green-600">${userData.referralEarnings.toFixed(2)}</p>
                    </div>
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                      <i className="ri-user-star-line text-2xl text-green-600"></i>
                    </div>
                  </div>
                  <div className="text-center">
                    <Button className="w-full" onClick={() => navigate('/withdraw-earnings')}>
                      <i className="ri-withdraw-line mr-2"></i>
                      Withdraw Earnings
                    </Button>
                  </div>
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>

      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Share Referral Link</h3>
              <button
                onClick={() => setShowShareModal(false)}
                className="text-gray-400 hover:text-gray-600 cursor-pointer"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            
            <p className="text-gray-600 mb-6">
              Share your referral link and earn commissions when people join through your link.
            </p>
            
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => shareVia('whatsapp')}
                className="flex items-center justify-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer"
              >
                <i className="ri-whatsapp-line text-green-600 text-xl mr-2"></i>
                <span className="text-sm font-medium">WhatsApp</span>
              </button>
              
              <button
                onClick={() => shareVia('telegram')}
                className="flex items-center justify-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer"
              >
                <i className="ri-telegram-line text-blue-600 text-xl mr-2"></i>
                <span className="text-sm font-medium">Telegram</span>
              </button>
              
              <button
                onClick={() => shareVia('twitter')}
                className="flex items-center justify-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer"
              >
                <i className="ri-twitter-line text-blue-400 text-xl mr-2"></i>
                <span className="text-sm font-medium">Twitter</span>
              </button>
              
              <button
                onClick={() => shareVia('facebook')}
                className="flex items-center justify-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer"
              >
                <i className="ri-facebook-line text-blue-700 text-xl mr-2"></i>
                <span className="text-sm font-medium">Facebook</span>
              </button>
              
              <button
                onClick={() => shareVia('email')}
                className="flex items-center justify-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer"
              >
                <i className="ri-mail-line text-gray-600 text-xl mr-2"></i>
                <span className="text-sm font-medium">Email</span>
              </button>
              
              <button
                onClick={copyReferralLink}
                className="flex items-center justify-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer"
              >
                <i className="ri-file-copy-line text-gray-600 text-xl mr-2"></i>
                <span className="text-sm font-medium">Copy Link</span>
              </button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}
