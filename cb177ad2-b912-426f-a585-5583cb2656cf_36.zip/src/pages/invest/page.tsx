
import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import Button from '../../components/base/Button';
import Card from '../../components/base/Card';
import { supabase } from '../../lib/supabase';

export default function Invest() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const planName = searchParams.get('plan') || 'WC-R550';
  
  const [formData, setFormData] = useState({
    amount: '',
    plan: planName,
    agreeTerms: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [userBalance, setUserBalance] = useState(0);
  const [user, setUser] = useState<any>(null);

  const plans = {
    'WC-R130': { min: 8, daily: '3.8%', total: '159.6%', duration: 42 },
    'WC-R550': { min: 32, daily: '3.8%', total: '163.4%', duration: 43 },
    'WC-R1150': { min: 67, daily: '3.8%', total: '167.2%', duration: 44 },
    'WC-R2000': { min: 116, daily: '3.8%', total: '171%', duration: 45 },
    'WC-R3100': { min: 179, daily: '3.8%', total: '174.8%', duration: 46 }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const { data: { user: authUser } } = await supabase.auth.getUser();
    if (!authUser) {
      navigate('/login');
      return;
    }

    // Get user profile
    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', authUser.id)
      .single();

    if (profile) {
      setUser(profile);
      setUserBalance(profile.balance);
    }
  };

  const selectedPlan = plans[formData.plan as keyof typeof plans];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setIsLoading(true);
    
    try {
      const investmentAmount = parseFloat(formData.amount);
      const expectedReturns = investmentAmount * (parseFloat(selectedPlan.total.replace('%', '')) / 100);
      
      // Calculate dates
      const startDate = new Date();
      const endDate = new Date();
      endDate.setDate(startDate.getDate() + selectedPlan.duration);

      // Create investment record
      const { data: investment, error: investmentError } = await supabase
        .from('investments')
        .insert({
          user_id: user.user_id,
          plan_id: formData.plan,
          plan_name: formData.plan,
          amount: investmentAmount,
          expected_returns: expectedReturns,
          current_returns: 0,
          status: 'active',
          start_date: startDate.toISOString(),
          end_date: endDate.toISOString()
        })
        .select()
        .single();

      if (investmentError) throw investmentError;

      // Update user profile
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          balance: user.balance - investmentAmount,
          total_invested: user.total_invested + investmentAmount,
          active_investments: user.active_investments + 1,
          updated_at: new Date().toISOString()
        })
        .eq('user_id', user.user_id);

      if (profileError) throw profileError;

      // Create investment transaction
      const { error: transactionError } = await supabase
        .from('transactions')
        .insert({
          user_id: user.user_id,
          type: 'investment',
          amount: -investmentAmount,
          status: 'completed',
          description: `Investment in ${formData.plan}`,
          reference_id: investment.id
        });

      if (transactionError) throw transactionError;

      // Process referral bonus if user was referred
      if (user.referral_code && user.referral_code !== user.user_id.slice(0, 8)) {
        const referralBonus = investmentAmount * 0.05; // 5% referral bonus
        
        // Find referrer
        const { data: referrer } = await supabase
          .from('profiles')
          .select('*')
          .eq('referral_code', user.referral_code.slice(0, 8))
          .single();

        if (referrer) {
          // Update referrer balance
          await supabase
            .from('profiles')
            .update({
              balance: referrer.balance + referralBonus,
              referral_earnings: referrer.referral_earnings + referralBonus,
              updated_at: new Date().toISOString()
            })
            .eq('user_id', referrer.user_id);

          // Create referral transaction
          await supabase
            .from('transactions')
            .insert({
              user_id: referrer.user_id,
              type: 'referral_bonus',
              amount: referralBonus,
              status: 'completed',
              description: `Referral bonus from ${user.first_name} ${user.last_name}'s investment`
            });
        }
      }

      setShowConfirmation(true);
      
    } catch (error) {
      console.error('Investment error:', error);
      alert('Investment failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const expectedReturns = formData.amount ? 
    (parseFloat(formData.amount) * parseFloat(selectedPlan.total.replace('%', '')) / 100).toFixed(2) : '0.00';

  if (showConfirmation) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-md mx-auto">
            <Card className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-rocket-2-line text-3xl text-green-600"></i>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Investment Successful!</h2>
              <p className="text-gray-600 mb-6">
                Your investment of ${formData.amount} in {formData.plan} has been activated. 
                You'll start earning returns immediately.
              </p>
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                <div className="text-sm space-y-1">
                  <div className="flex justify-between">
                    <span className="text-green-800">Investment Amount:</span>
                    <span className="text-green-900 font-medium">${formData.amount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-green-800">Expected Returns:</span>
                    <span className="text-green-900 font-medium">${expectedReturns}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-green-800">Duration:</span>
                    <span className="text-green-900 font-medium">{selectedPlan.duration} days</span>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <Button className="w-full" onClick={() => navigate('/dashboard')}>
                  View Dashboard
                </Button>
                <Button variant="outline" className="w-full" onClick={() => navigate('/plans')}>
                  View Other Plans
                </Button>
              </div>
            </Card>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Make Investment</h2>
            <p className="mt-2 text-gray-600">Start your investment journey today</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Investment Details</h3>
              
              <div className="mb-6 bg-gray-50 rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">Available Balance:</span>
                  <span className="font-semibold text-gray-899">${userBalance.toFixed(2)} USDT</span>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => navigate('/deposit')}
                  className="w-full"
                >
                  <i className="ri-add-line mr-1"></i>
                  Add Funds
                </Button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="plan" className="block text-sm font-medium text-gray-700 mb-2">
                    Investment Plan *
                  </label>
                  <div className="relative">
                    <select
                      id="plan"
                      name="plan"
                      value={formData.plan}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 pr-8 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm appearance-none"
                    >
                      {Object.keys(plans).map((plan) => (
                        <option key={plan} value={plan}>{plan}</option>
                      ))}
                    </select>
                    <i className="ri-arrow-down-s-line absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                  </div>
                </div>

                <div>
                  <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-2">
                    Investment Amount (USDT) *
                  </label>
                  <input
                    type="number"
                    id="amount"
                    name="amount"
                    value={formData.amount}
                    onChange={handleInputChange}
                    min={selectedPlan.min}
                    max={userBalance}
                    step="0.01"
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    placeholder={selectedPlan.min.toString()}
                  />
                  <p className="mt-1 text-xs text-gray-500">
                    Minimum investment: ${selectedPlan.min} USDT
                  </p>
                </div>

                <div className="flex items-start">
                  <input
                    id="agreeTerms"
                    name="agreeTerms"
                    type="checkbox"
                    checked={formData.agreeTerms}
                    onChange={handleInputChange}
                    required
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded cursor-pointer mt-0.5"
                  />
                  <label htmlFor="agreeTerms" className="ml-2 block text-sm text-gray-700 cursor-pointer">
                    I agree to the{' '}
                    <button type="button" className="text-blue-600 hover:text-blue-500 underline">
                      Terms and Conditions
                    </button>
                    {' '}and understand the investment risks.
                  </label>
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={isLoading || !formData.amount || !formData.agreeTerms || parseFloat(formData.amount) < selectedPlan.min || parseFloat(formData.amount) > userBalance}
                >
                  {isLoading ? (
                    <>
                      <i className="ri-loader-2-line animate-spin mr-2"></i>
                      Processing Investment...
                    </>
                  ) : (
                    <>
                      <i className="ri-rocket-2-line mr-2"></i>
                      Invest Now
                    </>
                  )}
                </Button>
              </form>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Plan Summary</h3>
              
              <div className="space-y-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="font-medium text-blue-900 mb-2">{formData.plan}</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-blue-800">Daily Return:</span>
                      <span className="text-blue-900 font-medium">{selectedPlan.daily}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-800">Total Return:</span>
                      <span className="text-blue-900 font-medium">{selectedPlan.total}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-800">Duration:</span>
                      <span className="text-blue-900 font-medium">{selectedPlan.duration} days</span>
                    </div>
                  </div>
                </div>

                {formData.amount && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-medium text-green-900 mb-2">Your Investment</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-green-800">Investment Amount:</span>
                        <span className="text-green-900 font-medium">${formData.amount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-green-800">Expected Returns:</span>
                        <span className="text-green-900 font-medium">${expectedReturns}</span>
                      </div>
                      <div className="flex justify-between border-t pt-2">
                        <span className="text-green-900 font-medium">Total Payout:</span>
                        <span className="text-green-900 font-bold">
                          ${(parseFloat(formData.amount) + parseFloat(expectedReturns)).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                <div className="text-center pt-4">
                  <button
                    onClick={() => navigate('/plans')}
                    className="text-sm text-blue-600 hover:text-blue-500 cursor-pointer"
                  >
                    View All Plans
                  </button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
