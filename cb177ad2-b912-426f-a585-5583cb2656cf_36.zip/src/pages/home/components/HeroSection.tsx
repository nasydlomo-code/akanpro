
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../../../components/base/Button';

export default function HeroSection() {
  const navigate = useNavigate();

  return (
    <section 
      className="relative bg-cover bg-center bg-no-repeat min-h-[600px] flex items-center"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://readdy.ai/api/search-image?query=Modern%20professional%20investment%20office%20with%20digital%20trading%20screens%20showing%20cryptocurrency%20charts%2C%20blue%20and%20gold%20color%20scheme%2C%20clean%20minimalist%20design%2C%20professional%20lighting%2C%20financial%20technology%20concept%2C%20high-tech%20investment%20environment%20with%20holographic%20displays&width=1200&height=600&seq=hero-investment&orientation=landscape')`
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="text-center text-white">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Secure Your Financial Future
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto text-gray-200">
            Invest in USDT with guaranteed returns. Choose from our professionally managed 
            investment plans and watch your wealth grow with complete transparency.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" onClick={() => navigate('/register')} className="bg-blue-600 hover:bg-blue-700">
              <i className="ri-rocket-2-line mr-2"></i>
              Start Investing Now
            </Button>
            <Button variant="outline" size="lg" onClick={() => navigate('/plans')} className="border-white text-white hover:bg-white hover:text-gray-900">
              <i className="ri-eye-line mr-2"></i>
              View Plans
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
