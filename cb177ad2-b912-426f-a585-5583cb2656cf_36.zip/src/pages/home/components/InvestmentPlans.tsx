
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../../../components/base/Card';
import Button from '../../../components/base/Button';

export default function InvestmentPlans() {
  const navigate = useNavigate();

  const plans = [
    {
      name: 'WC-R130',
      subtitle: 'Starter Plan',
      price: '$8',
      duration: '42 Days',
      dailyReturn: '3.8%',
      totalReturn: '159.6%',
      features: [
        'Minimum investment: $8',
        'Daily returns: 3.8%',
        'Total return: 159.6%',
        'Instant withdrawals',
        'Email support'
      ],
      popular: false,
      color: 'border-green-200'
    },
    {
      name: 'WC-R550',
      subtitle: 'Entry Plan',
      price: '$32',
      duration: '43 Days',
      dailyReturn: '3.8%',
      totalReturn: '163.4%',
      features: [
        'Minimum investment: $32',
        'Daily returns: 3.8%',
        'Total return: 163.4%',
        'Instant withdrawals',
        'Email support'
      ],
      popular: false,
      color: 'border-blue-200'
    },
    {
      name: 'WC-R1150',
      subtitle: 'Mid Plan',
      price: '$67',
      duration: '44 Days',
      dailyReturn: '3.8%',
      totalReturn: '167.2%',
      features: [
        'Minimum investment: $67',
        'Daily returns: 3.8%',
        'Total return: 167.2%',
        'Priority withdrawals',
        'Phone & email support',
        'Investment advisor'
      ],
      popular: true,
      color: 'border-green-200'
    },
    {
      name: 'WC-R2000',
      subtitle: 'Advanced Plan',
      price: '$116',
      duration: '45 Days',
      dailyReturn: '3.8%',
      totalReturn: '171%',
      features: [
        'Minimum investment: $116',
        'Daily returns: 3.8%',
        'Total return: 171%',
        'VIP withdrawal priority',
        '24/7 dedicated support',
        'Personal account manager',
        'Advanced analytics'
      ],
      popular: false,
      color: 'border-purple-200'
    },
    {
      name: 'WC-R3100',
      subtitle: 'Premium Plan',
      price: '$179',
      duration: '46 Days',
      dailyReturn: '3.8%',
      totalReturn: '174.8%',
      features: [
        'Minimum investment: $179',
        'Daily returns: 3.8%',
        'Total return: 174.8%',
        'Instant VIP withdrawals',
        '24/7 premium support',
        'Dedicated investment team',
        'Custom investment strategies',
        'Monthly profit reports'
      ],
      popular: false,
      color: 'border-yellow-200'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Choose Your Investment Plan
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our professionally managed investment plans are designed to maximize your returns 
            while minimizing risk. All investments are backed by our expert trading team.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {plans.map((plan, index) => (
            <Card key={index} className={`relative ${plan.color} ${plan.popular ? 'ring-2 ring-green-500' : ''}`}>
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-green-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="text-center mb-6">
                <h3 className="text-lg font-bold text-gray-900 mb-2">{plan.name}</h3>
                <p className="text-sm text-gray-600 mb-4">{plan.subtitle}</p>
                <div className="text-2xl font-bold text-blue-600 mb-2">{plan.price}</div>
                <p className="text-gray-600">{plan.duration} Investment</p>
              </div>

              <div className="mb-6">
                <div className="flex justify-between items-center py-2 border-b">
                  <span className="text-gray-600">Daily Return:</span>
                  <span className="font-semibold text-green-600">{plan.dailyReturn}</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-600">Total Return:</span>
                  <span className="font-semibold text-green-600">{plan.totalReturn}</span>
                </div>
              </div>

              <ul className="space-y-2 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-start">
                    <i className="ri-check-line text-green-500 mr-2 mt-0.5"></i>
                    <span className="text-sm text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button 
                className="w-full" 
                variant={plan.popular ? 'primary' : 'outline'}
                onClick={() => navigate(`/invest?plan=${encodeURIComponent(plan.name)}`)}
              >
                Choose Plan
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
