
import React from 'react';

export default function HowItWorks() {
  const steps = [
    {
      icon: 'ri-user-add-line',
      title: 'Create Account',
      description: 'Sign up with your email and verify your identity. Our registration process is quick and secure.',
      image: 'https://readdy.ai/api/search-image?query=Professional%20person%20creating%20account%20on%20laptop%2C%20modern%20office%20setting%2C%20clean%20interface%20design%2C%20digital%20registration%20process%2C%20blue%20and%20white%20color%20scheme%2C%20professional%20lighting%2C%20technology%20concept&width=400&height=300&seq=step1-register&orientation=landscape'
    },
    {
      icon: 'ri-wallet-3-line',
      title: 'Deposit USDT',
      description: 'Fund your account with USDT using our secure payment gateway. Multiple deposit methods available.',
      image: 'https://readdy.ai/api/search-image?query=Digital%20wallet%20showing%20USDT%20cryptocurrency%20deposit%2C%20secure%20payment%20interface%2C%20blockchain%20technology%2C%20modern%20financial%20app%20design%2C%20green%20and%20blue%20colors%2C%20professional%20setup&width=400&height=300&seq=step2-deposit&orientation=landscape'
    },
    {
      icon: 'ri-line-chart-line',
      title: 'Choose Plan',
      description: 'Select from our four investment plans based on your risk tolerance and investment goals.',
      image: 'https://readdy.ai/api/search-image?query=Investment%20plan%20selection%20interface%2C%20multiple%20investment%20options%20displayed%2C%20financial%20charts%20and%20graphs%2C%20professional%20trading%20platform%2C%20blue%20and%20gold%20color%20scheme%2C%20modern%20design&width=400&height=300&seq=step3-plan&orientation=landscape'
    },
    {
      icon: 'ri-money-dollar-circle-line',
      title: 'Earn Returns',
      description: 'Watch your investment grow with daily returns. Track your progress in real-time through your dashboard.',
      image: 'https://readdy.ai/api/search-image?query=Profit%20growth%20chart%20showing%20increasing%20returns%2C%20financial%20dashboard%20with%20positive%20trending%20graphs%2C%20success%20visualization%2C%20green%20and%20blue%20colors%2C%20professional%20financial%20interface&width=400&height=300&seq=step4-earn&orientation=landscape'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            How It Works
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Start your investment journey in just four simple steps. 
            Our platform makes investing in cryptocurrency safe and profitable.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="text-center group">
              <div className="relative mb-6">
                <img 
                  src={step.image} 
                  alt={step.title}
                  className="w-full h-48 object-cover rounded-lg shadow-md group-hover:shadow-lg transition-shadow duration-300"
                />
                <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2">
                  <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white shadow-lg">
                    <i className={`${step.icon} text-xl`}></i>
                  </div>
                </div>
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-3 mt-4">
                {step.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {step.description}
              </p>
              
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-24 left-full w-full">
                  <i className="ri-arrow-right-line text-2xl text-gray-300 transform -translate-x-1/2"></i>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
