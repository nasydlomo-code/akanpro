
import React from 'react';
import Card from '../../../components/base/Card';

export default function PlatformApproach() {
  const approaches = [
    {
      icon: 'ri-shield-check-line',
      title: 'Security First',
      description: 'Your investments are protected by bank-level security, multi-factor authentication, and cold storage for digital assets.',
      color: 'text-blue-600'
    },
    {
      icon: 'ri-eye-line',
      title: 'Full Transparency',
      description: 'Track every transaction, view real-time performance, and access detailed reports of your investment activities.',
      color: 'text-green-600'
    },
    {
      icon: 'ri-team-line',
      title: 'Expert Management',
      description: 'Our experienced trading team uses advanced algorithms and market analysis to maximize your returns.',
      color: 'text-purple-600'
    },
    {
      icon: 'ri-customer-service-2-line',
      title: '24/7 Support',
      description: 'Get help whenever you need it with our round-the-clock customer support team and dedicated account managers.',
      color: 'text-orange-600'
    },
    {
      icon: 'ri-money-dollar-circle-line',
      title: 'Guaranteed Returns',
      description: 'We guarantee the promised returns on all investment plans with our risk management and diversified portfolio.',
      color: 'text-emerald-600'
    },
    {
      icon: 'ri-global-line',
      title: 'Global Access',
      description: 'Invest from anywhere in the world with our globally accessible platform and multi-currency support.',
      color: 'text-indigo-600'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Our Platform Approach
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We've built our investment platform on six core principles that ensure 
            your success and peace of mind while maximizing your returns.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {approaches.map((approach, index) => (
            <Card key={index} className="text-center hover:shadow-lg transition-shadow duration-300">
              <div className={`w-16 h-16 mx-auto mb-6 rounded-full bg-gray-100 flex items-center justify-center ${approach.color}`}>
                <i className={`${approach.icon} text-2xl`}></i>
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                {approach.title}
              </h3>
              
              <p className="text-gray-600 leading-relaxed">
                {approach.description}
              </p>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-white rounded-lg shadow-md p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Why Choose InvestPro?
            </h3>
            <p className="text-gray-600 text-lg leading-relaxed mb-6">
              With over 5 years of experience in cryptocurrency trading and investment management, 
              we've helped thousands of investors achieve their financial goals. Our proven track record, 
              combined with cutting-edge technology and transparent operations, makes us the trusted choice 
              for serious investors.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-3xl font-bold text-blue-600 mb-2">$50M+</div>
                <div className="text-gray-600">Total Investments</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-green-600 mb-2">10,000+</div>
                <div className="text-gray-600">Active Investors</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-purple-600 mb-2">99.8%</div>
                <div className="text-gray-600">Success Rate</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
