
import React from 'react';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import HeroSection from './components/HeroSection';
import PlatformApproach from './components/PlatformApproach';
import HowItWorks from './components/HowItWorks';
import InvestmentPlans from './components/InvestmentPlans';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <HeroSection />
      <PlatformApproach />
      <HowItWorks />
      <InvestmentPlans />
      <Footer />
    </div>
  );
}
