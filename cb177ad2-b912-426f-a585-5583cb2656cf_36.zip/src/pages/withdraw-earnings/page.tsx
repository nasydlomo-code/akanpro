import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import Button from '../../components/base/Button';
import Card from '../../components/base/Card';

export default function WithdrawEarnings() {
  const navigate = useNavigate();
  const [withdrawalMethod, setWithdrawalMethod] = useState('usdt');
  const [formData, setFormData] = useState({
    amount: '',
    // USDT fields
    usdtAddress: '',
    // Fiat fields
    bankName: '',
    accountNumber: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);

  const availableEarnings = 847.25;
  const minimumWithdraw = 25;
  const usdtFee = 2;
  const fiatFee = 5;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleMethodChange = (method: string) => {
    setWithdrawalMethod(method);
    // Clear form data when switching methods
    setFormData({
      amount: formData.amount,
      usdtAddress: '',
      bankName: '',
      accountNumber: ''
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate withdrawal processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsLoading(false);
    setShowConfirmation(true);
  };

  const currentFee = withdrawalMethod === 'usdt' ? usdtFee : fiatFee;
  const netAmount = formData.amount ? (parseFloat(formData.amount) - currentFee).toFixed(2) : '0.00';

  if (showConfirmation) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-md mx-auto">
            <Card className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-check-line text-3xl text-green-600"></i>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Earnings Withdrawal Requested</h2>
              <p className="text-gray-600 mb-6">
                Your {withdrawalMethod === 'usdt' ? 'USDT' : 'bank'} withdrawal of ${netAmount} has been submitted. 
                It will be processed within {withdrawalMethod === 'usdt' ? '24 hours' : '3-5 business days'}.
              </p>
              <div className="space-y-3">
                <Button className="w-full" onClick={() => navigate('/dashboard')}>
                  View Dashboard
                </Button>
                <Button variant="outline" className="w-full" onClick={() => navigate('/')}>
                  Back to Home
                </Button>
              </div>
            </Card>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Withdraw Earnings</h2>
            <p className="mt-2 text-gray-600">Cash out your referral and investment earnings</p>
          </div>

          <Card className="p-8">
            <div className="mb-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Available Earnings:</span>
                <span className="font-bold text-xl text-green-600">${availableEarnings.toFixed(2)}</span>
              </div>
            </div>

            {/* Withdrawal Method Selection */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Select Withdrawal Method
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => handleMethodChange('usdt')}
                  className={`p-4 border-2 rounded-lg text-center cursor-pointer transition-all ${
                    withdrawalMethod === 'usdt'
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <div className="w-8 h-8 mx-auto mb-2 flex items-center justify-center">
                    <i className="ri-currency-line text-2xl"></i>
                  </div>
                  <div className="font-medium">USDT</div>
                  <div className="text-xs text-gray-500">BEP20 Network</div>
                </button>

                <button
                  type="button"
                  onClick={() => handleMethodChange('fiat')}
                  className={`p-4 border-2 rounded-lg text-center cursor-pointer transition-all ${
                    withdrawalMethod === 'fiat'
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <div className="w-8 h-8 mx-auto mb-2 flex items-center justify-center">
                    <i className="ri-bank-line text-2xl"></i>
                  </div>
                  <div className="font-medium">Bank Transfer</div>
                  <div className="text-xs text-gray-500">Fiat Currency</div>
                </button>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-2">
                  Withdrawal Amount (USD) *
                </label>
                <input
                  type="number"
                  id="amount"
                  name="amount"
                  value={formData.amount}
                  onChange={handleInputChange}
                  min={minimumWithdraw}
                  max={availableEarnings}
                  step="0.01"
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  placeholder="100.00"
                />
                <p className="mt-1 text-xs text-gray-500">
                  Minimum withdrawal: ${minimumWithdraw} USD
                </p>
              </div>

              {withdrawalMethod === 'usdt' && (
                <div>
                  <label htmlFor="usdtAddress" className="block text-sm font-medium text-gray-700 mb-2">
                    USDT BEP20 Address *
                  </label>
                  <input
                    type="text"
                    id="usdtAddress"
                    name="usdtAddress"
                    value={formData.usdtAddress}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    placeholder="0x1234567890abcdef1234567890abcdef12345678"
                  />
                  <p className="mt-1 text-xs text-gray-500">
                    Enter your BEP20 USDT wallet address. Double-check for accuracy.
                  </p>
                </div>
              )}

              {withdrawalMethod === 'fiat' && (
                <>
                  <div>
                    <label htmlFor="bankName" className="block text-sm font-medium text-gray-700 mb-2">
                      Bank Name *
                    </label>
                    <input
                      type="text"
                      id="bankName"
                      name="bankName"
                      value={formData.bankName}
                      onChange={handleInputChange}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      placeholder="Enter your bank name"
                    />
                  </div>

                  <div>
                    <label htmlFor="accountNumber" className="block text-sm font-medium text-gray-700 mb-2">
                      Account Number *
                    </label>
                    <input
                      type="text"
                      id="accountNumber"
                      name="accountNumber"
                      value={formData.accountNumber}
                      onChange={handleInputChange}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      placeholder="Enter your account number"
                    />
                    <p className="mt-1 text-xs text-gray-500">
                      Ensure your account number is correct to avoid processing delays.
                    </p>
                  </div>
                </>
              )}

              {formData.amount && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="text-sm font-medium text-blue-900 mb-2">Withdrawal Summary</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-blue-800">Withdrawal Amount:</span>
                      <span className="text-blue-900">${formData.amount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-800">Processing Fee:</span>
                      <span className="text-blue-900">${currentFee}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-800">Method:</span>
                      <span className="text-blue-900">{withdrawalMethod === 'usdt' ? 'USDT BEP20' : 'Bank Transfer'}</span>
                    </div>
                    <div className="flex justify-between border-t pt-1">
                      <span className="text-blue-900 font-medium">You will receive:</span>
                      <span className="text-blue-900 font-medium">${netAmount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-800">Processing Time:</span>
                      <span className="text-blue-900">{withdrawalMethod === 'usdt' ? '24 hours' : '3-5 business days'}</span>
                    </div>
                  </div>
                </div>
              )}

              <Button
                type="submit"
                className="w-full"
                disabled={
                  isLoading || 
                  !formData.amount || 
                  parseFloat(formData.amount) < minimumWithdraw ||
                  (withdrawalMethod === 'usdt' && !formData.usdtAddress) ||
                  (withdrawalMethod === 'fiat' && (!formData.bankName || !formData.accountNumber))
                }
              >
                {isLoading ? (
                  <>
                    <i className="ri-loader-2-line animate-spin mr-2"></i>
                    Processing...
                  </>
                ) : (
                  <>
                    <i className="ri-money-dollar-box-line mr-2"></i>
                    Request Withdrawal
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-sm text-blue-600 hover:text-blue-500 cursor-pointer"
              >
                Back to Dashboard
              </button>
            </div>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}