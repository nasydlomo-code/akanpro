
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          user_id: string
          first_name: string
          last_name: string
          email: string
          phone?: string
          balance: number
          total_invested: number
          total_returns: number
          active_investments: number
          referral_code: string
          referral_earnings: number
          total_team_members: number
          direct_referrals: number
          status: 'active' | 'suspended' | 'pending'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          first_name: string
          last_name: string
          email: string
          phone?: string
          balance?: number
          total_invested?: number
          total_returns?: number
          active_investments?: number
          referral_code: string
          referral_earnings?: number
          total_team_members?: number
          direct_referrals?: number
          status?: 'active' | 'suspended' | 'pending'
          created_at?: string
          updated_at?: string
        }
        Update: {
          first_name?: string
          last_name?: string
          email?: string
          phone?: string
          balance?: number
          total_invested?: number
          total_returns?: number
          active_investments?: number
          referral_earnings?: number
          total_team_members?: number
          direct_referrals?: number
          status?: 'active' | 'suspended' | 'pending'
          updated_at?: string
        }
      }
      investments: {
        Row: {
          id: string
          user_id: string
          plan_id: string
          plan_name: string
          amount: number
          expected_returns: number
          current_returns: number
          status: 'active' | 'completed' | 'cancelled'
          start_date: string
          end_date: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          plan_id: string
          plan_name: string
          amount: number
          expected_returns: number
          current_returns?: number
          status?: 'active' | 'completed' | 'cancelled'
          start_date: string
          end_date: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          current_returns?: number
          status?: 'active' | 'completed' | 'cancelled'
          updated_at?: string
        }
      }
      transactions: {
        Row: {
          id: string
          user_id: string
          type: 'deposit' | 'withdrawal' | 'investment' | 'returns' | 'transfer' | 'referral_bonus'
          amount: number
          status: 'pending' | 'completed' | 'failed' | 'cancelled'
          description?: string
          reference_id?: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          type: 'deposit' | 'withdrawal' | 'investment' | 'returns' | 'transfer' | 'referral_bonus'
          amount: number
          status?: 'pending' | 'completed' | 'failed' | 'cancelled'
          description?: string
          reference_id?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          status?: 'pending' | 'completed' | 'failed' | 'cancelled'
          updated_at?: string
        }
      }
    }
  }
}
