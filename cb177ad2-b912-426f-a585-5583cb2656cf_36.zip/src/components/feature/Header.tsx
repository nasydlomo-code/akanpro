
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../base/Button';

export default function Header() {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b w-full">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-blue-600" style={{ fontFamily: '"Pacifico", serif' }}>
              InvestPro
            </h1>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <button onClick={() => navigate('/')} className="text-gray-700 hover:text-blue-600 cursor-pointer">
              Home
            </button>
            <button onClick={() => navigate('/plans')} className="text-gray-700 hover:text-blue-600 cursor-pointer">
              Plans
            </button>
            <button onClick={() => navigate('/invest')} className="text-gray-700 hover:text-blue-600 cursor-pointer">
              Invest
            </button>
            <button onClick={() => navigate('/transfer')} className="text-gray-700 hover:text-blue-600 cursor-pointer">
              Transfer
            </button>
            <button onClick={() => navigate('/dashboard')} className="text-gray-700 hover:text-blue-600 cursor-pointer">
              Dashboard
            </button>
          </nav>

          <div className="flex items-center space-x-4">
            {isLoggedIn ? (
              <>
                <Button variant="outline" onClick={() => navigate('/dashboard')}>
                  Dashboard
                </Button>
                <Button onClick={() => setIsLoggedIn(false)}>
                  Logout
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={() => navigate('/login')}>
                  Login
                </Button>
                <Button onClick={() => navigate('/register')}>
                  Register
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
