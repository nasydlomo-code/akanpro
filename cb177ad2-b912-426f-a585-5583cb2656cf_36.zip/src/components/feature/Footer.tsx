
import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-2xl font-bold mb-4" style={{ fontFamily: '"Pacifico", serif' }}>
              InvestPro
            </h3>
            <p className="text-gray-400 mb-4">
              Your trusted partner for secure cryptocurrency investments. We provide transparent, 
              profitable investment opportunities with guaranteed returns.
            </p>
            <div className="flex space-x-4">
              <i className="ri-facebook-fill text-xl hover:text-blue-400 cursor-pointer"></i>
              <i className="ri-twitter-fill text-xl hover:text-blue-400 cursor-pointer"></i>
              <i className="ri-telegram-fill text-xl hover:text-blue-400 cursor-pointer"></i>
              <i className="ri-linkedin-fill text-xl hover:text-blue-400 cursor-pointer"></i>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="/" className="hover:text-white cursor-pointer">Home</a></li>
              <li><a href="/plans" className="hover:text-white cursor-pointer">Investment Plans</a></li>
              <li><a href="/about" className="hover:text-white cursor-pointer">About Us</a></li>
              <li><a href="/contact" className="hover:text-white cursor-pointer">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Support</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-white cursor-pointer">Help Center</a></li>
              <li><a href="#" className="hover:text-white cursor-pointer">Terms of Service</a></li>
              <li><a href="#" className="hover:text-white cursor-pointer">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white cursor-pointer">Security</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 InvestPro. All rights reserved. | <a href="https://readdy.ai/?origin=logo" className="hover:text-white">Powered by Readdy</a></p>
        </div>
      </div>
    </footer>
  );
}
