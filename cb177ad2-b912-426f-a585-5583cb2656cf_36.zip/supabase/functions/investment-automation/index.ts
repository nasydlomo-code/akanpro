import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { action } = await req.json()

    if (action === 'process_daily_returns') {
      // Get all active investments
      const { data: investments, error: investmentsError } = await supabaseClient
        .from('investments')
        .select('*')
        .eq('status', 'active')

      if (investmentsError) throw investmentsError

      const today = new Date()
      const processedInvestments = []

      for (const investment of investments) {
        const startDate = new Date(investment.start_date)
        const endDate = new Date(investment.end_date)
        
        // Calculate days since start
        const daysSinceStart = Math.floor((today.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
        
        // Calculate daily return based on plan
        let dailyReturnRate = 0.038 // 3.8% default
        
        // Plan-specific rates
        switch (investment.plan_id) {
          case 'WC-R130': dailyReturnRate = 0.038; break
          case 'WC-R550': dailyReturnRate = 0.038; break
          case 'WC-R1150': dailyReturnRate = 0.038; break
          case 'WC-R2000': dailyReturnRate = 0.038; break
          case 'WC-R3100': dailyReturnRate = 0.038; break
        }

        const dailyReturn = investment.amount * dailyReturnRate

        // Check if investment should be completed
        if (today >= endDate) {
          // Complete the investment
          const { error: updateInvestmentError } = await supabaseClient
            .from('investments')
            .update({ 
              status: 'completed',
              current_returns: investment.expected_returns,
              updated_at: new Date().toISOString()
            })
            .eq('id', investment.id)

          if (updateInvestmentError) throw updateInvestmentError

          // Get user profile
          const { data: profile, error: profileError } = await supabaseClient
            .from('profiles')
            .select('*')
            .eq('user_id', investment.user_id)
            .single()

          if (profileError) throw profileError

          // Update user balance with final returns
          const { error: updateProfileError } = await supabaseClient
            .from('profiles')
            .update({ 
              balance: profile.balance + investment.expected_returns,
              total_returns: profile.total_returns + investment.expected_returns,
              active_investments: Math.max(0, profile.active_investments - 1),
              updated_at: new Date().toISOString()
            })
            .eq('user_id', investment.user_id)

          if (updateProfileError) throw updateProfileError

          // Create completion transaction
          const { error: transactionError } = await supabaseClient
            .from('transactions')
            .insert({
              user_id: investment.user_id,
              type: 'returns',
              amount: investment.expected_returns,
              status: 'completed',
              description: `Investment completion returns for ${investment.plan_name}`,
              reference_id: investment.id
            })

          if (transactionError) throw transactionError

          processedInvestments.push({
            id: investment.id,
            action: 'completed',
            amount: investment.expected_returns
          })

        } else if (daysSinceStart > 0) {
          // Process daily return
          const { data: profile, error: profileError } = await supabaseClient
            .from('profiles')
            .select('*')
            .eq('user_id', investment.user_id)
            .single()

          if (profileError) throw profileError

          // Update user balance with daily return
          const { error: updateProfileError } = await supabaseClient
            .from('profiles')
            .update({ 
              balance: profile.balance + dailyReturn,
              total_returns: profile.total_returns + dailyReturn,
              updated_at: new Date().toISOString()
            })
            .eq('user_id', investment.user_id)

          if (updateProfileError) throw updateProfileError

          // Update investment current returns
          const { error: updateInvestmentError } = await supabaseClient
            .from('investments')
            .update({ 
              current_returns: investment.current_returns + dailyReturn,
              updated_at: new Date().toISOString()
            })
            .eq('id', investment.id)

          if (updateInvestmentError) throw updateInvestmentError

          // Create daily return transaction
          const { error: transactionError } = await supabaseClient
            .from('transactions')
            .insert({
              user_id: investment.user_id,
              type: 'returns',
              amount: dailyReturn,
              status: 'completed',
              description: `Daily returns for ${investment.plan_name}`,
              reference_id: investment.id
            })

          if (transactionError) throw transactionError

          processedInvestments.push({
            id: investment.id,
            action: 'daily_return',
            amount: dailyReturn
          })
        }
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          processed: processedInvestments.length,
          investments: processedInvestments,
          timestamp: new Date().toISOString()
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      )
    }

    if (action === 'process_referral_bonuses') {
      // Get all users with referrals
      const { data: profiles, error: profilesError } = await supabaseClient
        .from('profiles')
        .select('*')
        .gt('direct_referrals', 0)

      if (profilesError) throw profilesError

      const processedBonuses = []

      for (const profile of profiles) {
        // Calculate referral bonus (5% of total team investments)
        const { data: referralInvestments, error: referralError } = await supabaseClient
          .from('investments')
          .select('amount')
          .in('user_id', [profile.user_id]) // This would need proper referral tracking

        if (referralError) continue

        const totalReferralInvestments = referralInvestments.reduce((sum, inv) => sum + inv.amount, 0)
        const referralBonus = totalReferralInvestments * 0.05 // 5% bonus

        if (referralBonus > profile.referral_earnings) {
          const newBonus = referralBonus - profile.referral_earnings

          // Update profile with new referral earnings
          const { error: updateError } = await supabaseClient
            .from('profiles')
            .update({ 
              balance: profile.balance + newBonus,
              referral_earnings: referralBonus,
              updated_at: new Date().toISOString()
            })
            .eq('user_id', profile.user_id)

          if (updateError) continue

          // Create referral bonus transaction
          const { error: transactionError } = await supabaseClient
            .from('transactions')
            .insert({
              user_id: profile.user_id,
              type: 'referral_bonus',
              amount: newBonus,
              status: 'completed',
              description: 'Referral bonus from team investments'
            })

          if (transactionError) continue

          processedBonuses.push({
            user_id: profile.user_id,
            bonus: newBonus
          })
        }
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          processed: processedBonuses.length,
          bonuses: processedBonuses,
          timestamp: new Date().toISOString()
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      )
    }

    return new Response(
      JSON.stringify({ error: 'Invalid action' }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400 
      }
    )

  } catch (error) {
    console.error('Automation error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    )
  }
})